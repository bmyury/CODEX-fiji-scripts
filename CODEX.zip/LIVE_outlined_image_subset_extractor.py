from ij import IJ, ImagePlus, ImageStack
from ij.io import DirectoryChooser, OpenDialog, FileSaver
from os import walk
import re
import os
from ij.gui import GenericDialog,NonBlockingGenericDialog, Overlay, Roi, PolygonRoi, TextRoi, WaitForUserDialog
from ij.measure import ResultsTable
from java.awt import Color, Font


od = OpenDialog("Choose a dataset file", None)  
datasetfile = od.getFileName() 
srcDir = od.getDirectory()
datasetpath = os.path.join(srcDir, od.getFileName())
#	print(datasetpath)
datasetsource = open(datasetpath, "r+")
datasetlines=re.split('\n|\r',datasetsource.read().replace('"', ''))
#	print(len(datasetlines))


datasetmatrix=[re.split(",|\t",datasetlines[i]) for i in range(len(datasetlines)) if len(re.split(",|\t",datasetlines[i]))>3]
#	datasetmatrix=readCSV(datasetpath)

#	print("datasetmatrix size is "+str(len(datasetmatrix)))

datacolnames=datasetmatrix[0]
datasetmatrix=datasetmatrix[1:]

scalingfactor=0.5
xshift=0
yshift=0
X_coord_column = 0
column1_ID = 0
column2_ID = 0
Y_coord_column = 0

	
	
yesno='Yes'
while yesno == 'Yes':
	

	gd = NonBlockingGenericDialog("scaling factor and shift params")
	gd.addNumericField("scaling factor", scalingfactor,3)
	gd.addNumericField("xshift", xshift,3)
	gd.addNumericField("yshift", yshift,3)	
	gd.addChoice("X coord column",datacolnames,datacolnames[X_coord_column])
	gd.addChoice("Y coord column",datacolnames,datacolnames[Y_coord_column])
	gd.addStringField("gatename", "proliferating tumor")
	gd.addStringField("exit?", "no")

	
	gd.showDialog()
	
	scalingfactor=gd.getNextNumber()
	xshift=gd.getNextNumber()
	yshift=gd.getNextNumber()	
	X_coord_column=gd.getNextChoiceIndex()
	Y_coord_column=gd.getNextChoiceIndex()
	gatename = gd.getNextString()
	exit_or_stay = gd.getNextString()


	if exit_or_stay=="yes":
		break
	
	
	imp = IJ.getImage()
	mask=imp.createRoiMask()
	mask_imp=ImagePlus("segmframe", mask)
	#mask_imp.show()
	
	gated_subset=[elem for elem in datasetmatrix if mask_imp.getPixel(int(round(float(elem[X_coord_column])*scalingfactor)),int(round(float(elem[Y_coord_column])*scalingfactor)))[0]>0]
	not_in_gated_subset=[elem for elem in datasetmatrix if mask_imp.getPixel(int(round(float(elem[X_coord_column])*scalingfactor)),int(round(float(elem[Y_coord_column])*scalingfactor)))[0]==0]
			
	dc = DirectoryChooser("Choose directory to store the result")
	resultDir = dc.getDirectory()
	emptytiles = open(resultDir+gatename+".txt", "w+")
	emptytiles.write(datasetlines[0]+'\n')
	for i in range(0,len(gated_subset)):
		emptytiles.write(",".join(gated_subset[i])+'\n')				
	emptytiles.close()

	emptytiles = open(resultDir+"not_in_"+gatename+".txt", "w+")
	emptytiles.write(datasetlines[0]+'\n')
	for i in range(0,len(not_in_gated_subset)):
		emptytiles.write(",".join(not_in_gated_subset[i])+'\n')				
	emptytiles.close()

	stack=ImageStack(700, 700)

	fs = FileSaver(mask_imp)
	fs.saveAsTiff(resultDir+gatename+"_mask.tif")
			
	#	outcropped.close()
	


	
		