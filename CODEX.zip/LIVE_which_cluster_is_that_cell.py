#this script locates and shows with crosses cells of a selected cluster
# niche_clustering.csv with is an export from Vortex and has cluster in the first column  is the input dataset file for this script

from ij import IJ
from ij.io import DirectoryChooser, OpenDialog
from os import walk
import re
import os
from ij.gui import GenericDialog, Overlay, Roi, PolygonRoi, TextRoi, WaitForUserDialog
#from java.awt import Color
from ij.measure import ResultsTable
#from ij.io import FileSaver 

overlay=Overlay()

imp = IJ.getImage()

if (imp.getOverlay()):
	print ("found overlay")
	overlay=imp.getOverlay()

forever="yes"

while  forever=="yes" :

	results=ResultsTable()
	


	od = OpenDialog("Choose a dataset file", None)  
	datasetfile = od.getFileName() 
	srcDir = od.getDirectory()
	datasetpath = os.path.join(srcDir, od.getFileName())
	datasetsource = open(datasetpath, "r+")
	datasetlines=re.split('\n|\r',datasetsource.read())
	print(len(datasetlines))

	datasetmatrix=[re.split(",|\t",datasetlines[i]) for i in range(len(datasetlines)) if len(re.split(",|\t",datasetlines[i]))>3]

	print("datasetmatrix size is "+str(len(datasetmatrix)))

	datacolnames=datasetmatrix[0]
	datasetmatrix=datasetmatrix[1:]


	gd = GenericDialog("table subsetting")
	gd.addStringField("subset the table", "no")
	gd.addChoice("Subsetting Column",datacolnames,datacolnames[0])
	gd.showDialog()
	subset_or_not=gd.getNextString()
	subsetting_column=gd.getNextChoiceIndex()

	if subset_or_not=="yes":
		results=ResultsTable()
		elements=[elem[subsetting_column] for elem in datasetmatrix]
		unique_elements=list(set(elements))
		filledwithTrue=[False for elem in unique_elements]
		gd = GenericDialog("select one element")
		gd.addCheckboxGroup(len(unique_elements), 1, unique_elements, filledwithTrue)
		gd.showDialog()
		checkedIDs=gd.getCheckboxes()
		IDs=[elem.getLabel() for elem in checkedIDs if elem.getState() is True]
		print(len(IDs))
		datasetmatrix=[elem for elem in datasetmatrix if elem[subsetting_column]==IDs[0]]
		

	
	gd = GenericDialog("scaling factor and shift params")
	gd.addNumericField("scaling factor", 0.5,3)
	gd.addNumericField("xshift", 0,0)
	gd.addNumericField("yshift", 0,0)
	
	gd.addChoice("X coord column",datacolnames,datacolnames[0])
	gd.addChoice("Y coord column",datacolnames,datacolnames[0])
	gd.showDialog()
	
	scalingfactor=gd.getNextNumber()
	xshift=gd.getNextNumber()
	yshift=gd.getNextNumber()
	
	X_coord_column=gd.getNextChoiceIndex()
	Y_coord_column=gd.getNextChoiceIndex()
	
	removeoverlay = "no"
	
	yesno='Yes'
	while yesno == 'Yes':
	
	
		results=ResultsTable()	
	
		gd = GenericDialog("keep the overlay?")

		gd.addStringField("removeoverlay", removeoverlay)
		gd.showDialog()

		removeoverlay = gd.getNextString()


		if removeoverlay == 'none':
			break

		
		wait=WaitForUserDialog('draw rectangular ROI','press OK to continue')
		wait.show()

		if removeoverlay == 'yes':
			overlay=Overlay()
	
#######################################################

		roi=imp.getProcessor().getRoi()	
		
		y_top_left = (float(roi.y)-yshift)/scalingfactor
		x_top_left = (float(roi.x)-xshift)/scalingfactor
		width = roi.width/scalingfactor
		height = roi.height/scalingfactor
		
		
		x_btm_right = x_top_left + float(width)
		y_btm_right = y_top_left + float(height)
	
					
		print('calculating perROI subset')
		perROIsubset=[elem for elem in datasetmatrix if float(elem[X_coord_column]) > x_top_left and float(elem[X_coord_column]) < x_btm_right and float(elem[Y_coord_column]) > y_top_left and float(elem[Y_coord_column]) < y_btm_right]
		print(x_top_left)
		print(y_top_left)
		print(x_btm_right)
		print(y_btm_right)

		print(len(perROIsubset))

	
		x=[xshift+float(elem[X_coord_column])*scalingfactor for elem in perROIsubset]
		y=[yshift+float(elem[Y_coord_column])*scalingfactor for elem in perROIsubset]
	
				
		for i in range(0,len(x)):
			roi = Roi(x[i]-5, y[i], 11, 1)
			overlay.add(roi)
			roi = Roi(x[i], y[i]-5, 1, 11)
			overlay.add(roi)
			
		imp.setOverlay(overlay)
		imp.show()
		
		#results.addLabel("bla")
		for i in range(0,len(perROIsubset)):
			results.incrementCounter();
			for k in range(0,len(datacolnames)):
				results.addValue(datacolnames[k],perROIsubset[i][k])
		results.show("Results")
		
		wait=WaitForUserDialog('what is that cell','waiting...')
		wait.show()
#######################################################                                                                                                                                                                                                                                                        


