#this script locates and shows with crosses cells of a selected cluster
# niche_clustering.csv with is an export from Vortex and has cluster in the first column  is the input dataset file for this script

from ij import IJ, ImagePlus, ImageStack
from ij.process import ImageProcessor, ShortProcessor, ByteProcessor
from ij.io import DirectoryChooser, OpenDialog
from os import walk
import re
import math
import os
import copy
from ij.gui import GenericDialog, NonBlockingGenericDialog, Overlay, Roi, OvalRoi, Line, PolygonRoi, TextRoi, WaitForUserDialog, NonBlockingGenericDialog
from java.awt import Color
from ij.measure import ResultsTable
from ij.io import FileSaver
from ij.plugin import HyperStackConverter
from java.awt import Font
from util.opencsv import CSVReader
from java.io import FileReader
from ij.plugin.frame import RoiManager

def readCSV(filepath):
   reader = CSVReader(FileReader(filepath), ",")
   ls = reader.readAll()
   return ls

overlay=Overlay()

imp = IJ.getImage()

if (imp.getOverlay()):
	print ("found overlay")
	overlay=imp.getOverlay()
	
exit_or_stay="no"

forever="yes"

while  forever=="yes" :

	if exit_or_stay=="yes":
		break

	results=ResultsTable()
	
	od = OpenDialog("Choose a dataset file", None)  
	datasetfile = od.getFileName() 
	srcDir = od.getDirectory()
	datasetpath = os.path.join(srcDir, od.getFileName())
#	print(datasetpath)
	datasetsource = open(datasetpath, "r+")
	datasetlines=re.split('\n|\r',datasetsource.read().replace('"', ''))
#	print(len(datasetlines))

	
	datasetmatrix=[re.split(",|\t",datasetlines[i]) for i in range(len(datasetlines)) if len(re.split(",|\t",datasetlines[i]))>3]
#	datasetmatrix=readCSV(datasetpath)

#	print("datasetmatrix size is "+str(len(datasetmatrix)))

	datacolnames=datasetmatrix[0]
	datasetmatrix=datasetmatrix[1:]

	gd = GenericDialog("table subsetting")
	gd.addStringField("subset the table", "yes")
	gd.addChoice("Subsetting Column",datacolnames,datacolnames[0])
	gd.addStringField("subsetting values comma sep", "Tregs,Tregs PD1hi,Tregs ICOShi,CD4 T cells ICOShi")
	gd.addStringField("exit?", "no")
	gd.showDialog()
	subset_or_not=gd.getNextString()
	subsetting_column=gd.getNextChoiceIndex()
	subsetting_string = gd.getNextString()
	subsetting_string_split=color=set(subsetting_string.split(','))
	exit_or_stay = gd.getNextString()

	if exit_or_stay=="yes":
		break
	

	if subset_or_not=="yes":
		
		datasetmatrix=[elem for elem in datasetmatrix if elem[subsetting_column] in subsetting_string_split]
		
		print("subsetted datasetmatrix size is "+str(len(datasetmatrix)))


	
	xshift=0
	yshift=0
	X_coord_column = 0
	column1_ID = 0
	column2_ID = 0
	Y_coord_column = 0

	col1_morethen = "0.01"
	col1_lessthen = "10"

	col2_morethen = "0.01"
	col2_lessthen = "10"	
	color_input="0,255,0"
	removeoverlay = "no"
	column1_scaletype = "linear"
	column2_scaletype = "linear"

	x_crossing_lines_string="1,2,4"
	y_crossing_lines_string="1,2,4"

	symbol="cross"
	symbol_size=5
	stroke_thickness=1

	old_xshift=xshift
	old_yshift=yshift
	old_column1_ID=column1_ID
	old_column1_scaletype=column1_scaletype
	old_col1_morethen=col1_morethen
	old_col1_lessthen=col1_lessthen
	old_x_crossing_lines_string=x_crossing_lines_string
	old_column2_ID = column2_ID
	old_column2_scaletype=column2_scaletype
	old_col2_morethen=col2_morethen
	old_col2_lessthen=col2_lessthen
	old_y_crossing_lines_string=y_crossing_lines_string


	
	
	yesno='Yes'
	while yesno == 'Yes':
		

		gd = NonBlockingGenericDialog("scaling factor and shift params")
		gd.addNumericField("scaling factor", 0.5,3)
		gd.addNumericField("xshift", xshift,3)
		gd.addNumericField("yshift", yshift,3)	
		gd.addChoice("X coord column",datacolnames,datacolnames[X_coord_column])
		gd.addChoice("Y coord column",datacolnames,datacolnames[Y_coord_column])
		gd.addChoice("biaxial horizontal",datacolnames,datacolnames[column1_ID])
		gd.addStringField("log or linear", column1_scaletype)
		gd.addStringField("scale min", col1_morethen)
		gd.addStringField("scale max", col1_lessthen)
		gd.addStringField("draw lines at", x_crossing_lines_string)
		gd.addChoice("biaxial vertical",datacolnames,datacolnames[column2_ID])
		gd.addStringField("log or linear", column2_scaletype)
		gd.addStringField("scale min", col2_morethen)
		gd.addStringField("scale max", col2_lessthen)
		gd.addStringField("draw lines at", y_crossing_lines_string)
		gd.addStringField("cell color", color_input)
		gd.addChoice("symbol",["cross","empty oval","filled oval","filled square","empty square"],symbol)
		gd.addNumericField("symbol size",symbol_size,3)
		gd.addNumericField("stroke thickness",stroke_thickness,3)
		gd.addStringField("removeoverlay", removeoverlay)
		gd.addStringField("export the gate", "no")		
		gd.addStringField("exit?", "no")
		
		gd.showDialog()
		
		scalingfactor=gd.getNextNumber()
		xshift=gd.getNextNumber()
		yshift=gd.getNextNumber()	
		X_coord_column=gd.getNextChoiceIndex()
		Y_coord_column=gd.getNextChoiceIndex()
		column1_ID = gd.getNextChoiceIndex()
		column1_scaletype = gd.getNextString()	
		col1_morethen = gd.getNextString()
		col1_lessthen = gd.getNextString()
		x_crossing_lines_string = gd.getNextString()
		x_crossing_lines=x_crossing_lines_string.split(",")
		column2_ID = gd.getNextChoiceIndex()
		column2_scaletype = gd.getNextString()	
		col2_morethen = gd.getNextString()
		col2_lessthen = gd.getNextString()
		y_crossing_lines_string = gd.getNextString()
		y_crossing_lines=y_crossing_lines_string.split(",")
		color_input=gd.getNextString()
		symbol=gd.getNextChoice()
		symbol_size=gd.getNextNumber()
		stroke_thickness=gd.getNextNumber()
		removeoverlay = gd.getNextString()
		export_yesno=gd.getNextString()
		exit_or_stay = gd.getNextString()

		if exit_or_stay=="yes":
			break

		if 	(xshift!=old_xshift or yshift!=old_yshift or column1_ID != old_column1_ID or column1_scaletype != old_column1_scaletype or col1_morethen != old_col1_morethen or col1_lessthen != old_col1_lessthen or x_crossing_lines_string != old_x_crossing_lines_string or column2_ID != old_column2_ID or column2_scaletype != old_column2_scaletype or col2_morethen != old_col2_morethen or col2_lessthen != old_col2_lessthen or y_crossing_lines_string != old_y_crossing_lines_string):

			datasetmatrix_copy=copy.deepcopy(datasetmatrix)


			old_xshift=xshift
			old_yshift=yshift
			old_column1_ID=column1_ID
			old_column1_scaletype=column1_scaletype
			old_col1_morethen=col1_morethen
			old_col1_lessthen=col1_lessthen
			old_x_crossing_lines_string=x_crossing_lines_string
			old_column2_ID = column2_ID
			old_column2_scaletype=column2_scaletype
			old_col2_morethen=col2_morethen
			old_col2_lessthen=col2_lessthen
			old_y_crossing_lines_string=y_crossing_lines_string

				
		
			if column1_scaletype=="linear":
				x_range=float(col1_lessthen)-float(col1_morethen)
			if column1_scaletype=="log":
				x_range=math.log(float(col1_lessthen)/float(col1_morethen),2)
			if column2_scaletype=="linear":
				y_range=float(col2_lessthen)-float(col2_morethen)
			if column2_scaletype=="log":
				y_range=math.log(float(col2_lessthen)/float(col2_morethen),2)
	
			
	
			xscaling=500/x_range
			yscaling=500/y_range
	
			if column1_ID == 'none':
				break
	
			plotframe=ByteProcessor(700, 700)
			
			for k in range(len(datasetmatrix)):
	
				if float(datasetmatrix[k][column1_ID]) < float(col1_morethen):
					datasetmatrix_copy[k][column1_ID]=col1_morethen		
				if float(datasetmatrix[k][column1_ID]) > float(col1_lessthen):
					datasetmatrix_copy[k][column1_ID]=col1_lessthen
				if float(datasetmatrix[k][column2_ID])< float(col2_morethen):
					datasetmatrix_copy[k][column2_ID]=col2_morethen			
				if float(datasetmatrix[k][column2_ID]) > float(col2_lessthen):
					datasetmatrix_copy[k][column2_ID]=col2_lessthen
	
	# this segment draws teh biaxial plot		
			for line in datasetmatrix_copy:
				if column1_scaletype=="linear":
					xplot=int(round((float(line[column1_ID])-float(col1_morethen))*xscaling))
				if column1_scaletype=="log":
					xplot=int(round((math.log(float(line[column1_ID]),2)-math.log(float(col1_morethen),2))*xscaling))
				if column2_scaletype=="linear":
					yplot=int(round((float(line[column2_ID])-float(col2_morethen))*yscaling))
				if column2_scaletype=="log":
					yplot=int(round((math.log(float(line[column2_ID]),2)-math.log(float(col2_morethen),2))*yscaling))
				
				plotframe.setf(100+xplot,100+yplot,250)
	
			plotframe_imp=ImagePlus("biaxial", plotframe)
	
			textoverlay=Overlay()
			roi = TextRoi(100, 50, "------"+datacolnames[column1_ID]+"----->", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
	
			roi = TextRoi(33, 90, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 120, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 150, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 180, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 210, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 240, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 270, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 300, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 330, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 360, "|", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 400, "V", Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
			roi = TextRoi(33, 620, datacolnames[column2_ID], Font("SanSerif", Font.PLAIN, 28))
			roi.setStrokeColor(Color(255,255,255))
			textoverlay.add(roi)
	
			if len(x_crossing_lines)>0:
				for line in x_crossing_lines:
					if column1_scaletype=="linear":
						x_tick=int(round((float(line)-float(col1_morethen))*xscaling))+1
						roi = Line(100+x_tick, 100, 100+x_tick, 600)
						roi.setStrokeColor(Color(255,0,0))
						roi.setStrokeWidth(2)
						textoverlay.add(roi)
					if column1_scaletype=="log":
						x_tick=int(round((math.log(float(line),2)-math.log(float(col1_morethen),2))*xscaling))+1
						roi = Line(100+x_tick, 100, 100+x_tick, 600)
						roi.setStrokeColor(Color(255,0,0))
						roi.setStrokeWidth(2)
						textoverlay.add(roi)
	
			
			if len(y_crossing_lines)>0:
				for line in y_crossing_lines:
					if column2_scaletype=="linear":
						y_tick=int(round((float(line)-float(col2_morethen))*yscaling))+1
						roi = Line(100,100+y_tick,600,100+y_tick)
						roi.setStrokeColor(Color(255,0,0))
						roi.setStrokeWidth(2)
						textoverlay.add(roi)
					if column2_scaletype=="log":
						y_tick=int(round((math.log(float(line),2)-math.log(float(col2_morethen),2))*yscaling))+1
						roi = Line(100,100+y_tick,600,100+y_tick)
						roi.setStrokeColor(Color(255,0,0))
						roi.setStrokeWidth(2)
						textoverlay.add(roi)
	
	
						
			plotframe_imp.setOverlay(textoverlay)
	
			plotframe_imp.show()
###################################################finished making new plot############################
		mask=plotframe_imp.createRoiMask()				
		mask_imp=ImagePlus("segmframe", mask)

		if removeoverlay == 'yes':
			overlay=Overlay()


		color=color_input.split(',')

		col = Color(int(color[0]),int(color[1]),int(color[2]))

		plotframe_overlay=plotframe_imp.getOverlay()
		plotroi=plotframe_imp.getRoi()
		if plotroi:
					
			plotroi.setStrokeColor(col)
			plotframe_overlay.add(plotroi)
			plotframe_imp.show()

		gated_subset=[]

		for i in range(0,len(datasetmatrix)):

			if column1_scaletype=="linear":
				deltax=float(datasetmatrix_copy[i][column1_ID])
				xadd=float(col1_morethen)
			if column1_scaletype=="log":
				deltax=math.log(float(datasetmatrix_copy[i][column1_ID]),2)
				xadd=math.log(float(col1_morethen),2)

			if column2_scaletype=="linear":
				deltay=float(datasetmatrix_copy[i][column2_ID])
				yadd=float(col2_morethen)
			if column2_scaletype=="log":
				deltay=math.log(float(datasetmatrix_copy[i][column2_ID]),2)
				yadd=math.log(float(col2_morethen),2)
		
			if mask_imp.getPixel(100+int(round((deltax-xadd)*xscaling)),100+int(round((deltay-yadd)*yscaling)))[0]>200:
				gated_subset.append(datasetmatrix[i])

		

		print("length of subset is"+str(len(gated_subset)))
		print(len(gated_subset))
		x=[(xshift+float(elem[X_coord_column]))*scalingfactor for elem in gated_subset]
		y=[(yshift+float(elem[Y_coord_column]))*scalingfactor for elem in gated_subset]
	
				
		if symbol=="cross":
			for g in range(0,len(x)):
			
				col = Color(int(color[0]),int(color[1]),int(color[2]))
				roi = Roi(x[g]-symbol_size, y[g], 2*symbol_size+1, 1)
	#			roi.setFillColor(col)
				roi.setStrokeColor(col)
				roi.setStrokeWidth(stroke_thickness)
				overlay.add(roi)
				roi = Roi(x[g], y[g]-symbol_size, 1, 2*symbol_size+1)
	#			roi.setFillColor(col)
				roi.setStrokeColor(col)
				roi.setStrokeWidth(stroke_thickness)
				overlay.add(roi)
		if symbol=="empty square":
			for g in range(0,len(x)):
			
				col = Color(int(color[0]),int(color[1]),int(color[2]))
				roi = Roi(x[g]-symbol_size, y[g]-symbol_size, 2*symbol_size+1, 2*symbol_size+1)
	#			roi.setFillColor(col)
				roi.setStrokeColor(col)
				roi.setStrokeWidth(stroke_thickness)
				overlay.add(roi)

		if symbol=="filled square":
			for g in range(0,len(x)):
			
				col = Color(int(color[0]),int(color[1]),int(color[2]))
				roi = Roi(x[g]-symbol_size, y[g]-symbol_size, 2*symbol_size+1, 2*symbol_size+1)
				roi.setFillColor(col)
				roi.setStrokeColor(col)
				roi.setStrokeWidth(stroke_thickness)
				overlay.add(roi)
			
		if symbol=="empty oval":

			for g in range(0,len(x)):
			
				col = Color(int(color[0]),int(color[1]),int(color[2]))
				roi = OvalRoi(x[g]-symbol_size, y[g]-symbol_size, 2*symbol_size+1, 2*symbol_size+1)
	#			roi.setFillColor(col)
				roi.setStrokeColor(col)
				roi.setStrokeWidth(stroke_thickness)
				overlay.add(roi)
	
		if symbol=="filled oval":
			for g in range(0,len(x)):
			
				col = Color(int(color[0]),int(color[1]),int(color[2]))
				roi = OvalRoi(x[g]-symbol_size, y[g]-symbol_size, 2*symbol_size+1, 2*symbol_size+1)
				roi.setFillColor(col)
				roi.setStrokeColor(col)
				roi.setStrokeWidth(stroke_thickness)
				overlay.add(roi)

			
		imp.setOverlay(overlay)
		imp.show()
	
		if export_yesno == 'yes':
			channel_name_1=datacolnames[column1_ID]
			channel_name_1=re.sub(r'[^A-Za-z0-9 ]+', '', channel_name_1)

			channel_name_2=datacolnames[column2_ID]
			channel_name_2=re.sub(r'[^A-Za-z0-9 ]+', '', channel_name_2)

			gatename=channel_name_1 +"_"+channel_name_2
			dc = DirectoryChooser("Choose directory to store the result")
			resultDir = dc.getDirectory()
			emptytiles = open(resultDir+gatename+".txt", "w+")
			emptytiles.write(datasetlines[0]+'\n')
			for i in range(0,len(gated_subset)):
				emptytiles.write(",".join(gated_subset[i])+'\n')				
			emptytiles.close()

			stack=ImageStack(700, 700)

			stack.addSlice("biaxial",plotframe)
			stack.addSlice("gate",mask)

			imp2 = ImagePlus("combo", stack) 
			imp2.setOverlay(textoverlay)

			result=HyperStackConverter().toHyperStack(imp2,2,1,1)
			fs = FileSaver(result)
			fs.saveAsTiff(resultDir+channel_name_1+"_"+col1_morethen+"To"+col1_lessthen+"_"+channel_name_2+"_"+col2_morethen+"To"+col2_lessthen+"_gate.tif")


	

