#this script locates and shows with crosses cells of a selected cluster
# niche_clustering.csv with is an export from Vortex and has cluster in the first column  is the input dataset file for this script

from ij import IJ, ImagePlus, ImageStack
from ij.process import ImageProcessor, ShortProcessor, ByteProcessor
from ij.io import DirectoryChooser, OpenDialog
from os import walk
import re
import math
import os
import copy
from ij.gui import GenericDialog, Overlay, Roi, PolygonRoi, TextRoi, WaitForUserDialog, NonBlockingGenericDialog
from java.awt import Color
from ij.measure import ResultsTable
from ij.io import FileSaver
from ij.plugin import HyperStackConverter
from java.awt import Font

overlay=Overlay()

imp = IJ.getImage()

if (imp.getOverlay()):
	print ("found overlay")
	overlay=imp.getOverlay()

forever="yes"

while  forever=="yes" :

	results=ResultsTable()
	
	od = OpenDialog("Choose a dataset file", None)  
	datasetfile = od.getFileName() 
	srcDir = od.getDirectory()
	datasetpath = os.path.join(srcDir, od.getFileName())
	datasetsource = open(datasetpath, "r+")
	datasetlines=re.split('\n|\r',datasetsource.read().replace('"', ''))
	print(len(datasetlines))

	datasetmatrix=[re.split(",|\t",datasetlines[i]) for i in range(len(datasetlines)) if len(re.split(",|\t",datasetlines[i]))>3]
	datasetmatrix_copy=[re.split(",|\t",datasetlines[i]) for i in range(len(datasetlines)) if len(re.split(",|\t",datasetlines[i]))>3]
	print("datasetmatrix size is "+str(len(datasetmatrix)))

	datacolnames=datasetmatrix[0]
	datasetmatrix=datasetmatrix[1:]
	datasetmatrix_copy=datasetmatrix_copy[1:]

	X_coord_column = 0
	column1_ID = 0
	column2_ID = 0
	Y_coord_column = 0

	col1_morethen = "0"
	col1_lessthen = "30000"

	col2_morethen = "0"
	col2_lessthen = "30000"	
	color_input="0,255,0"
	removeoverlay = "no"
	column1_scaletype = "linear"
	column2_scaletype = "linear"		
	
	yesno='Yes'
	while yesno == 'Yes':
		gd = GenericDialog("scaling factor and shift params")
		gd.addNumericField("scaling factor", 0.5,3)
		gd.addNumericField("xshift", 0,3)
		gd.addNumericField("yshift", 0,3)	

		gd.addChoice("X coord column",datacolnames,datacolnames[X_coord_column])

		gd.addChoice("Y coord column",datacolnames,datacolnames[Y_coord_column])

		gd.addChoice("biaxial horizontal",datacolnames,datacolnames[column1_ID])
		gd.addStringField("log or linear", column1_scaletype)
		gd.addStringField("scale min", col1_morethen)
		gd.addStringField("scale max", col1_lessthen)

		gd.addChoice("biaxial vertical",datacolnames,datacolnames[column2_ID])
		gd.addStringField("log or linear", column2_scaletype)
		gd.addStringField("scale min", col2_morethen)
		gd.addStringField("scale max", col2_lessthen)
		gd.showDialog()
		
		scalingfactor=gd.getNextNumber()
		xshift=gd.getNextNumber()
		yshift=gd.getNextNumber()	

		X_coord_column=gd.getNextChoiceIndex()

		Y_coord_column=gd.getNextChoiceIndex()

		column1_ID = gd.getNextChoiceIndex()
		column1_scaletype = gd.getNextString()	
		col1_morethen = gd.getNextString()
		col1_lessthen = gd.getNextString()

		column2_ID = gd.getNextChoiceIndex()
		column2_scaletype = gd.getNextString()	
		col2_morethen = gd.getNextString()
		col2_lessthen = gd.getNextString()		
			
	
		if column1_scaletype=="linear":
			x_range=float(col1_lessthen)-float(col1_morethen)
		if column1_scaletype=="log":
			x_range=math.log(float(col1_lessthen)/float(col1_morethen),2)
		if column2_scaletype=="linear":
			y_range=float(col2_lessthen)-float(col2_morethen)
		if column2_scaletype=="log":
			y_range=math.log(float(col2_lessthen)/float(col2_morethen),2)

		

		xscaling=500/x_range
		yscaling=500/y_range

		if column1_ID == 'none':
			break

		plotframe=ByteProcessor(700, 700)
		
		for k in range(len(datasetmatrix)):

			if float(datasetmatrix[k][column1_ID]) < float(col1_morethen):
				datasetmatrix_copy[k][column1_ID]=col1_morethen		
			if float(datasetmatrix[k][column1_ID]) > float(col1_lessthen):
				datasetmatrix_copy[k][column1_ID]=col1_lessthen
			if float(datasetmatrix[k][column2_ID])< float(col2_morethen):
				datasetmatrix_copy[k][column2_ID]=col2_morethen			
			if float(datasetmatrix[k][column2_ID]) > float(col2_lessthen):
				datasetmatrix_copy[k][column2_ID]=col2_lessthen
		
		for line in datasetmatrix_copy[1:]:
			if column1_scaletype=="linear":
				xplot=int(round((float(line[column1_ID])-float(col1_morethen))*xscaling))
			if column1_scaletype=="log":
				xplot=int(round((math.log(float(line[column1_ID]),2)-math.log(float(col1_morethen),2))*xscaling))
			if column2_scaletype=="linear":
				yplot=int(round((float(line[column2_ID])-float(col2_morethen))*yscaling))
			if column2_scaletype=="log":
				yplot=int(round((math.log(float(line[column2_ID]),2)-math.log(float(col2_morethen),2))*yscaling))
			
			plotframe.setf(100+xplot,100+yplot,250)


		

		plotframe_imp=ImagePlus("biaxial", plotframe)

		textoverlay=Overlay()
		roi = TextRoi(500, 50, datacolnames[column1_ID], Font("SanSerif", Font.PLAIN, 28))
		roi.setStrokeColor(Color(255,255,255))
		textoverlay.add(roi)

		roi = TextRoi(25, 670, datacolnames[column2_ID], Font("SanSerif", Font.PLAIN, 28))
		roi.setStrokeColor(Color(255,255,255))
		textoverlay.add(roi)
					
		plotframe_imp.setOverlay(textoverlay)

		plotframe_imp.show()

		moving_gate_without_changing_plot='Yes'
		while moving_gate_without_changing_plot == 'Yes':

			gd = GenericDialog("set color for the cells in the gate")

			gd.addStringField("color1", color_input)
			gd.addStringField("removeoverlay", removeoverlay)
			gd.showDialog()
		
			color_input=gd.getNextString()
			removeoverlay = gd.getNextString()


			if color_input == 'none':
				break

			if removeoverlay == 'yes':
				overlay=Overlay()

	
			wait=WaitForUserDialog('draw ROI on plot','press OK to continue')
			wait.show()

			color=color_input.split(',')

			col = Color(int(color[0]),int(color[1]),int(color[2]))
	
			mask=plotframe_imp.createRoiMask()
			mask_imp=ImagePlus("segmframe", mask)



			gated_subset=[]


			for i in range(0,len(datasetmatrix[1:])):

				if column1_scaletype=="linear":
					deltax=float(datasetmatrix_copy[1+i][column1_ID])
					xadd=float(col1_morethen)
				if column1_scaletype=="log":
					deltax=math.log(float(datasetmatrix_copy[1+i][column1_ID]),2)
					xadd=math.log(float(col1_morethen),2)

				if column2_scaletype=="linear":
					deltay=float(datasetmatrix_copy[1+i][column2_ID])
					yadd=float(col2_morethen)
				if column2_scaletype=="log":
					deltay=math.log(float(datasetmatrix_copy[1+i][column2_ID]),2)
					yadd=math.log(float(col2_morethen),2)
			
				if mask_imp.getPixel(100+int(round((deltax-xadd)*xscaling)),100+int(round((deltay-yadd)*yscaling)))[0]>200:
					gated_subset.append(datasetmatrix[1+i])
	
			
	
			print("length of subset is"+str(len(gated_subset)))
			print(len(gated_subset))
			x=[(xshift+float(elem[X_coord_column]))*scalingfactor for elem in gated_subset]
			y=[(yshift+float(elem[Y_coord_column]))*scalingfactor for elem in gated_subset]
		
					
			for i in range(0,len(x)):
				roi = Roi(x[i]-3, y[i], 7, 1)
				roi.setStrokeColor(col)
				overlay.add(roi)
				roi = Roi(x[i], y[i]-3, 1, 7)
				roi.setStrokeColor(col)
				overlay.add(roi)

				
			imp.setOverlay(overlay)
			imp.show()
		
		

			gd = NonBlockingGenericDialog("proceed with or without exporting the gate")
			
			gd.addStringField("export the gate", "no")
			gd.showDialog()
			
			export_yesno=gd.getNextString()

			if export_yesno == 'yes':
				channel_name_1=datacolnames[column1_ID]
				channel_name_1=re.sub(r'[^A-Za-z0-9 ]+', '', channel_name_1)

				channel_name_2=datacolnames[column2_ID]
				channel_name_2=re.sub(r'[^A-Za-z0-9 ]+', '', channel_name_2)

				gatename=channel_name_1 +"_"+channel_name_2
				dc = DirectoryChooser("Choose directory to store the result")
				resultDir = dc.getDirectory()
				emptytiles = open(resultDir+gatename+".txt", "w+")
				emptytiles.write(datasetlines[0]+'\n')
				for i in range(0,len(gated_subset)):
					emptytiles.write(",".join(gated_subset[i])+'\n')				
				emptytiles.close()

				stack=ImageStack(700, 700)

				stack.addSlice("biaxial",plotframe)
				stack.addSlice("gate",mask)

				imp2 = ImagePlus("combo", stack) 
				imp2.setOverlay(textoverlay)

				result=HyperStackConverter().toHyperStack(imp2,2,1,1)
				fs = FileSaver(result)
				fs.saveAsTiff(resultDir+channel_name_1+"_"+col1_morethen+"To"+col1_lessthen+"_"+channel_name_2+"_"+col2_morethen+"To"+col2_lessthen+"_gate.tif")


	

