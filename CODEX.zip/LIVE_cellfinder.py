#this script locates and shows with crosses cells of a selected cluster
# niche_clustering.csv with is an export from Vortex and has cluster in the first column  is the input dataset file for this script

from ij import IJ, WindowManager
from ij.io import DirectoryChooser, OpenDialog
from os import walk
import re
import os
from ij.gui import GenericDialog, NonBlockingGenericDialog,  OvalRoi, Overlay, Roi, PolygonRoi, TextRoi, WaitForUserDialog
from java.awt import Color
from ij.measure import ResultsTable
from ij.io import FileSaver 
from util.opencsv import CSVReader
from java.io import FileReader

def readCSV(filepath):
   reader = CSVReader(FileReader(filepath), ",")
   ls = reader.readAll()
   return ls

columnID = 0
clusterID="11"
color_input="0,170,255"
removeoverlay = "no"
X_coord_column = 0
Y_coord_column = 0
map_or_whatisit="map"
symbol="cross"
symbol_size=5
matching_type="exact"
subsetting_value="smth"
symbol_size=11
stroke_thickness=5
subsetting_column=0
subset_or_not="no"


a = WindowManager



dataset_forever="yes"

while dataset_forever=="yes":
	
	od = OpenDialog("Choose a dataset file", None)  
	datasetfile = od.getFileName() 
	srcDir = od.getDirectory()
	datasetpath = os.path.join(srcDir, od.getFileName())
	
	datasetmatrix_ori=readCSV(datasetpath)
	
	
	print("original datasetmatrix size is "+str(len(datasetmatrix_ori)))
	
	
	datacolnames=datasetmatrix_ori[0]
	datasetmatrix_ori=datasetmatrix_ori[1:]
	
	gd = GenericDialog("input mode")
	filledwithTrue=[False, False, False]
	gd.addCheckboxGroup(3, 1, ["input params from file","input params from dialogue", "exit"], filledwithTrue)
	gd.showDialog()
	param_input_checkedIDs=gd.getCheckboxes()
	param_input_IDs=[elem.getLabel() for elem in param_input_checkedIDs if elem.getState() is True]

	
	if param_input_IDs[0]=="exit":
		break
	
	images_forever="yes"
	
	while images_forever=="yes":
		
		images=a.getImageTitles()
		images=images.tolist()
	
		images.append("exit")
		
		
		filledwithTrue=[False for elem in images]
		
		gd = NonBlockingGenericDialog("images")
		gd.addCheckboxGroup(len(images), 1, images, filledwithTrue)
		gd.showDialog()
		checkedIDs=gd.getCheckboxes()
		IDs=[elem.getLabel() for elem in checkedIDs if elem.getState() is True]	
		indexes=[checkedIDs.index(elem) for elem in checkedIDs if elem.getState() is True]
	
		if IDs[0]=="exit":
			break
		
		print(IDs)
		print(indexes)
		
		overlay=Overlay()
		
		imp = a.getImage(images[indexes[0]])
		
		if (imp.getOverlay()):
			print ("found overlay")
			overlay=imp.getOverlay()
	
			
		
		mapping_results=ResultsTable()
		
		yesno='Yes'
		while yesno == 'Yes':
		
			
			gd = NonBlockingGenericDialog("name the celltype,region abd color ")
			gd.addNumericField("scaling factor", 0.5,3)
			gd.addNumericField("xshift", 0,3)
			gd.addNumericField("yshift", 0,3)	
			gd.addChoice("X coord column",datacolnames,datacolnames[X_coord_column])
			gd.addChoice("Y coord column",datacolnames,datacolnames[Y_coord_column])
			gd.addChoice("map or whatisit",["map","whatisit"],map_or_whatisit)
			if param_input_IDs[0]=="input params from dialogue":
				gd.addStringField("subset the table", subset_or_not)
				gd.addChoice("Subsetting Column",datacolnames,datacolnames[subsetting_column])
				gd.addStringField("Subsetting value", subsetting_value)	
				gd.addChoice("Column with Value",datacolnames,datacolnames[columnID])
				gd.addChoice("matching type",["exact","regex"],matching_type)
				gd.addStringField("Table field Value (e.g. name of CLusterID)", clusterID)
				gd.addStringField("color1", color_input)
				gd.addChoice("symbol",["cross","empty oval","filled oval","filled square","empty square"],symbol)
				gd.addNumericField("symbol size",symbol_size,3)
				gd.addNumericField("stroke thickness",stroke_thickness,3)
			gd.addStringField("removeoverlay", removeoverlay)
			gd.addCheckboxGroup(1, 1, ["exit"], [False])
			gd.showDialog()
			scalingfactor=gd.getNextNumber()
			xshift=gd.getNextNumber()
			yshift=gd.getNextNumber()		
			X_coord_column=gd.getNextChoiceIndex()
			Y_coord_column=gd.getNextChoiceIndex()
			map_or_whatisit=gd.getNextChoice()
			if param_input_IDs[0]=="input params from dialogue":
				subset_or_not=gd.getNextString()
				subsetting_column=gd.getNextChoiceIndex()
				subsetting_value = gd.getNextString()
				columnID = gd.getNextChoiceIndex()
				matching_type = gd.getNextChoice()
				clusterID = gd.getNextString()	
				color_input=gd.getNextString()
				symbol=gd.getNextChoice()
				symbol_size=gd.getNextNumber()
				stroke_thickness=gd.getNextNumber()
			removeoverlay = gd.getNextString()
			checkedIDs=gd.getCheckboxes()
			indexes=[checkedIDs.index(elem) for elem in checkedIDs if elem.getState() is True]
		
			if len(indexes) > 0:
				break
		
		
		
			if map_or_whatisit=="map":
		
				if param_input_IDs[0]=="input params from file":
					od = OpenDialog("Choose a dataset file", None)  
					datasetfile = od.getFileName() 
					srcDir = od.getDirectory()
					param_datasetpath = os.path.join(srcDir, od.getFileName())			
					param_datasetmatrix=readCSV(param_datasetpath)
		
					if removeoverlay == 'yes':				
						mapping_results=ResultsTable()
						overlay=Overlay()
		
					for line_counter in range(1,len(param_datasetmatrix)):
		
						if len(param_datasetmatrix[line_counter])>3:
						
							columnID = int(param_datasetmatrix[line_counter][0])					
							clusterID = param_datasetmatrix[line_counter][1]	
							color_input=param_datasetmatrix[line_counter][2]
							symbol=param_datasetmatrix[line_counter][3]
							symbol_size=float(param_datasetmatrix[line_counter][4])
							stroke_thickness=float(param_datasetmatrix[line_counter][5])
							subset_or_not = param_datasetmatrix[line_counter][6]
							subsetting_column = int(param_datasetmatrix[line_counter][7])
							subsetting_value = param_datasetmatrix[line_counter][8]
							matching_type = param_datasetmatrix[line_counter][9]	
		
				if subset_or_not=="no":
					datasetmatrix=[elem for elem in datasetmatrix_ori]
				if subset_or_not=="yes":
	#				datasetmatrix=readCSV(datasetpath)
					datasetmatrix=[elem for elem in datasetmatrix_ori if elem[subsetting_column]==subsetting_value]

					print("data subset size is "+str(len(datasetmatrix)))
				if matching_type=="exact":
					subset=[elem for elem in datasetmatrix if elem[columnID] == clusterID]
				if matching_type=="regex":
					prog = re.compile(clusterID)		
					subset=[elem for elem in datasetmatrix if prog.match(elem[columnID])]
				print("subset size is "+str(len(subset)))		
				print("color is "+color_input)	
				color=color_input.split(',')
			
				if removeoverlay == 'yes':				
						mapping_results=ResultsTable()
						overlay=Overlay()
				x=[xshift+float(elem[X_coord_column])*scalingfactor for elem in subset]
				y=[yshift+float(elem[Y_coord_column])*scalingfactor for elem in subset]
				
				if symbol=="cross":
					for g in range(0,len(x)):
					
						col = Color(int(color[0]),int(color[1]),int(color[2]))
						roi = Roi(x[g]-symbol_size, y[g], 2*symbol_size+1, 1)
			#			roi.setFillColor(col)
						roi.setStrokeColor(col)
						roi.setStrokeWidth(stroke_thickness)
						overlay.add(roi)
						roi = Roi(x[g], y[g]-symbol_size, 1, 2*symbol_size+1)
			#			roi.setFillColor(col)
						roi.setStrokeColor(col)
						roi.setStrokeWidth(stroke_thickness)
						overlay.add(roi)
				if symbol=="empty square":
					for g in range(0,len(x)):
					
						col = Color(int(color[0]),int(color[1]),int(color[2]))
						roi = Roi(x[g]-symbol_size, y[g]-symbol_size, 2*symbol_size+1, 2*symbol_size+1)
			#			roi.setFillColor(col)
						roi.setStrokeColor(col)
						roi.setStrokeWidth(stroke_thickness)
						overlay.add(roi)
		
				if symbol=="filled square":
					for g in range(0,len(x)):
					
						col = Color(int(color[0]),int(color[1]),int(color[2]))
						roi = Roi(x[g]-symbol_size, y[g]-symbol_size, 2*symbol_size+1, 2*symbol_size+1)
						roi.setFillColor(col)
						roi.setStrokeColor(col)
						roi.setStrokeWidth(stroke_thickness)
						overlay.add(roi)
					
				if symbol=="empty oval":
		
					for g in range(0,len(x)):
					
						col = Color(int(color[0]),int(color[1]),int(color[2]))
						roi = OvalRoi(x[g]-symbol_size, y[g]-symbol_size, 2*symbol_size+1, 2*symbol_size+1)
			#			roi.setFillColor(col)
						roi.setStrokeColor(col)
						roi.setStrokeWidth(stroke_thickness)
						overlay.add(roi)
			
				if symbol=="filled oval":
					for g in range(0,len(x)):
					
						col = Color(int(color[0]),int(color[1]),int(color[2]))
						roi = OvalRoi(x[g]-symbol_size, y[g]-symbol_size, 2*symbol_size+1, 2*symbol_size+1)
						roi.setFillColor(col)
						roi.setStrokeColor(col)
						roi.setStrokeWidth(stroke_thickness)
						overlay.add(roi)
		
				mapping_results.incrementCounter()
						
				mapping_results.addValue("column",columnID)			
				mapping_results.addValue("ID",clusterID)
				mapping_results.addValue("color",color_input)					
				mapping_results.addValue("symbol",symbol)
				mapping_results.addValue("size",int(symbol_size))
				mapping_results.addValue("stroke width",int(stroke_thickness))
				mapping_results.addValue("subset_or_not",subset_or_not)
				mapping_results.addValue("subsetting_column",subsetting_column)
				mapping_results.addValue("subsetting_value",subsetting_value)
				mapping_results.addValue("matching type",matching_type)	
				mapping_results.show("Mapping Results")
		
				imp.setOverlay(overlay)
				imp.show()
		
			if map_or_whatisit=="whatisit":

				if subset_or_not=="no":
					datasetmatrix=[elem for elem in datasetmatrix_ori]
				if subset_or_not=="yes":
	#				datasetmatrix=readCSV(datasetpath)
					datasetmatrix=[elem for elem in datasetmatrix_ori if elem[subsetting_column]==subsetting_value]
		
				results=ResultsTable()	
				if removeoverlay == 'yes':
					overlay=Overlay()
		
				roi=imp.getProcessor().getRoi()	
				
				y_top_left = (float(roi.y)-yshift)/scalingfactor
				x_top_left = (float(roi.x)-xshift)/scalingfactor
				width = roi.width/scalingfactor
				height = roi.height/scalingfactor
							
				x_btm_right = x_top_left + float(width)
				y_btm_right = y_top_left + float(height)
			
							
				print('calculating perROI subset')
				perROIsubset=[elem for elem in datasetmatrix if float(elem[X_coord_column]) > x_top_left and float(elem[X_coord_column]) < x_btm_right and float(elem[Y_coord_column]) > y_top_left and float(elem[Y_coord_column]) < y_btm_right]
				print(x_top_left)
				print(y_top_left)
				print(x_btm_right)
				print(y_btm_right)
		
				print(len(perROIsubset))
		
			
				x=[xshift+float(elem[X_coord_column])*scalingfactor for elem in perROIsubset]
				y=[yshift+float(elem[Y_coord_column])*scalingfactor for elem in perROIsubset]
			
						
				for i in range(0,len(x)):
					roi = Roi(x[i]-symbol_size, y[i], 2*symbol_size+1, 1)
					overlay.add(roi)
					roi = Roi(x[i], y[i]-symbol_size, 1, 2*symbol_size+1)
					overlay.add(roi)
					
				imp.setOverlay(overlay)
				imp.show()
				
				#results.addLabel("bla")
				for i in range(0,len(perROIsubset)):
					results.incrementCounter()
					for k in range(0,len(datacolnames)):
						results.addValue(datacolnames[k],perROIsubset[i][k])
				results.show("Results")
		
			
			
		
