#this script locates and shows with crosses cells of a selected cluster
# niche_clustering.csv with is an export from Vortex and has cluster in the first column  is the input dataset file for this script

from ij import IJ, ImagePlus
from ij.io import DirectoryChooser, OpenDialog
from os import walk
import re
import os
from ij.gui import GenericDialog, Overlay, Roi, OvalRoi, PolygonRoi, TextRoi, WaitForUserDialog
from java.awt import Color, Checkbox
from ij.measure import ResultsTable
from ij.io import FileSaver
from ij.process import ImageStatistics, ImageProcessor, ByteProcessor


def median(data):
    """Return sum of square deviations of sequence data."""
    c =sorted(data)
    middle=len(c)//2
    return c[middle]

def mean(data):
	"""Return the sample arithmetic mean of data."""
	n = len(data)
	if n < 1:
	    raise ValueError('mean requires at least one data point')
	return sum(data)/n # in Python 2 use sum(data)/float(n)

def _ss(data):
    """Return sum of square deviations of sequence data."""
    c = mean(data)
    ss = sum((x-c)**2 for x in data)
    return ss

def stddev(data, ddof=0):
    """Calculates the population standard deviation
    by default; specify ddof=1 to compute the sample
    standard deviation."""
    n = len(data)
    if n < 2:
        raise ValueError('variance requires at least two data points')
    ss = _ss(data)
    pvar = ss/(n-ddof)
    return pvar**0.5


od = OpenDialog("Choose dataset file", None)  
datasetfile = od.getFileName() 
srcDir = od.getDirectory()
datasetpath = os.path.join(srcDir, od.getFileName())
datasetsource = open(datasetpath, "r+")


dc = DirectoryChooser("Choose directory for saving the results")
resultDir = dc.getDirectory()


gd = GenericDialog("how to split the table")
gd.addStringField("dataset OS Win or Mac (type none to exit the program)", "Win")
gd.addStringField("separator", "tab")
gd.showDialog()
eol=gd.getNextString()
separator=gd.getNextString()


if eol=="Win":
	datasetlines=datasetsource.read().split('\n')
if eol=="Mac":
	datasetlines=datasetsource.read().split('\r')
datasetsource.close()
print(len(datasetlines))


			
if separator=="comma":
	datasetmatrix=[datasetlines[i].split(",") for i in range(len(datasetlines)) if len(datasetlines[i].split(","))>3]
if separator=="tab":
	datasetmatrix=[datasetlines[i].split("\t") for i in range(len(datasetlines)) if len(datasetlines[i].split("\t"))>3]
print(len(datasetmatrix))

print("datasetmatrix size is "+str(len(datasetmatrix)))


for i in range(0,len(datasetmatrix[0])):
	IJ.log(str(i+1)+"_______"+datasetmatrix[0][i])

uniqueids=datasetmatrix[0]
filledwithTrue=[True for elem in uniqueids]

gd = GenericDialog("select markers to be mapped and check the X and Y column indexes")
gd.addCheckboxGroup(len(uniqueids)//4+4, 4, uniqueids, filledwithTrue)
gd.showDialog()
checkedIDs=gd.getCheckboxes()
IDs=[elem.getLabel() for elem in checkedIDs if elem.getState() is True]

gd = GenericDialog("scaling factor shift img template params")
gd.addNumericField("width of img template", 4992,0)
gd.addNumericField("height of img template", 5769,0)
gd.addNumericField("scaling factor", 0.5,3)
gd.addNumericField("xshift", 0,3)
gd.addNumericField("yshift", 0,3)

gd.addNumericField("X coord column index 1 based", 4,3)
gd.addNumericField("Y coord column index 1 based", 5,3)
gd.addNumericField("maximum in STDs", 4,2)

gd.showDialog()

width=int(gd.getNextNumber())
height=int(gd.getNextNumber())
scalingfactor=gd.getNextNumber()
xshift=gd.getNextNumber()
yshift=gd.getNextNumber()

X_coord_column=int(gd.getNextNumber())
Y_coord_column=int(gd.getNextNumber())
max_in_stds = gd.getNextNumber()




for w in range(0,len(IDs)):

	impnewprocessor=ByteProcessor(width,height)

	for k in range(0,len(datasetmatrix[0])):
		print (IDs[w]+"-------"+datasetmatrix[0][k].replace("_", " "))
		if (IDs[w]==datasetmatrix[0][k].replace("_", " ")):
			print("yesyes"+str(k))
			colnumber=k
			break

	selected_marker_column=[float(elem[colnumber]) for elem in datasetmatrix[1:]]
		
	maxofcol=max(selected_marker_column)
	minofcol=min(selected_marker_column)
	stdevofcol=stddev(selected_marker_column)
	medianofcol=median(selected_marker_column)
	leftthresh=medianofcol-stdevofcol

	print ("colnumber is " + str(colnumber))
	print ("maxofcol is " + str(maxofcol))
	print ("minofcol is " + str(minofcol))
	print("stdevofcol is " + str(stdevofcol))
	print("medianofcol is " + str(medianofcol))
	print("max_in_stds is " + str(max_in_stds))
	scalingdelta=medianofcol+max_in_stds*stdevofcol
	print("scalingdelta is " + str(scalingdelta))
	print("leftthresh is " + str(leftthresh))
	
		
	x=[xshift+float(elem[X_coord_column-1])*scalingfactor for elem in datasetmatrix[1:]]
	y=[yshift+float(elem[Y_coord_column-1])*scalingfactor for elem in datasetmatrix[1:]]
	colors=[1]*len(x)


	
	for colorsindex in range(0,len(datasetmatrix[1:])):
		colors[colorsindex]=int((float(datasetmatrix[colorsindex+1][colnumber])-leftthresh)/scalingdelta*255)
		if colors[colorsindex]<0:
			colors[colorsindex]=0
		if colors[colorsindex]>255:
			colors[colorsindex]=255
	print(datasetmatrix[colorsindex+1][1:50])

	

	for g in range(0,len(x)):


		impnewprocessor.setColor(colors[g])
		impnewprocessor.fillOval(int(x[g]), int(y[g]), 15, 15)

	
#		col = Color(colors[g],0,0)
#		roi = OvalRoi(x[g], y[g], 20, 20)
#		roi.setStrokeColor(col)
#		roi.setStrokeWidth(1)
#		roi.setFillColor(col)
#		overlay.add(roi)
	
	impnew=ImagePlus(IDs[w],impnewprocessor)

	namesplit=IDs[w].split(':')

	fs = FileSaver(impnew) 

	filepath = resultDir+"/"+namesplit[0]+".tif"
	fs.saveAsTiff(filepath)




