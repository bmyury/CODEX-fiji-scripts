#this script locates and shows with crosses cells of a selected cluster
# niche_clustering.csv with is an export from Vortex and has cluster in the first column  is the input dataset file for this script

from ij import IJ
from ij.io import DirectoryChooser, OpenDialog
from os import walk
import re
import os
from ij.gui import GenericDialog, Overlay, Roi, PolygonRoi, TextRoi, WaitForUserDialog
from java.awt import Color
from ij.measure import ResultsTable
from ij.io import FileSaver 

overlay=Overlay()

imp = IJ.getImage()

if (imp.getOverlay()):
	print ("found overlay")
	overlay=imp.getOverlay()

forever="yes"

while  forever=="yes" :

	results=ResultsTable()

	gd = GenericDialog("how to split the table")
	gd.addStringField("OS of dataset Win or Mac (type none to exit the program)", "Win")
	gd.addStringField("separator", "tab")
	gd.showDialog()
	eol=gd.getNextString()
	separator=gd.getNextString()

	if eol == 'none':
		break
	if separator == 'none':
		break
	
	od = OpenDialog("Choose a dataset file", None)  
	datasetfile = od.getFileName() 
	srcDir = od.getDirectory()
	datasetpath = os.path.join(srcDir, od.getFileName())
	datasetsource = open(datasetpath, "r+")
	if eol=="Win":
		datasetlines=datasetsource.read().split('\n')
	if eol=="Mac":
		datasetlines=datasetsource.read().split('\r')
	print(len(datasetlines))
	

	
	if separator=="comma":
		datasetmatrix=[datasetlines[i].split(",") for i in range(len(datasetlines)) if len(datasetlines[i].split(","))>3]
	if separator=="tab":
		datasetmatrix=[datasetlines[i].split("\t") for i in range(len(datasetlines)) if len(datasetlines[i].split("\t"))>3]
	print(len(datasetmatrix))
	datasetsource.close()
	print("datasetmatrix size is "+str(len(datasetmatrix)))


	for i in range(0,len(datasetmatrix[0])):
		results.incrementCounter();
		results.addValue("Column Number",i+1)
		results.addValue("Column ID",datasetmatrix[0][i])
	results.show("Results")

	wait=WaitForUserDialog('decide which column is of your interest','press OK to continue')
	wait.show()
	
	gd = GenericDialog("scaling factor and shift params")
	gd.addNumericField("scaling factor", 0.5,3)
	gd.addNumericField("xshift", 4992,3)
	gd.addNumericField("yshift", 0,3)
	
	gd.addNumericField("X coord column index 1 based", 3,3)
	gd.addNumericField("Y coord column index 1 based", 4,3)
	gd.showDialog()
	
	scalingfactor=gd.getNextNumber()
	xshift=gd.getNextNumber()
	yshift=gd.getNextNumber()
	
	X_coord_column=int(gd.getNextNumber())
	Y_coord_column=int(gd.getNextNumber())
	
	
	# open file	

	
	#overlay=Overlay()
	
	#overlay=imp.getProcessor().getRoi()
	#overlay=imp.getOverlay()
	
	columnID = "30"
	morethen = "-10000"
	lessthen = "70000"	
	color_input="0,255,0"
	removeoverlay = "no"
	
	yesno='Yes'
	while yesno == 'Yes':
	
	
		
	
		gd = GenericDialog("name the celltype,region abd color ")
		gd.addStringField("1 based column index", columnID)
		gd.addStringField("more then", morethen)
		gd.addStringField("less then", lessthen)
		gd.addStringField("color1", color_input)
		gd.addStringField("removeoverlay", removeoverlay)
		gd.showDialog()
		columnID = gd.getNextString()	
		morethen = gd.getNextString()
		lessthen = gd.getNextString()	
		color_input=gd.getNextString()
		removeoverlay = gd.getNextString()

		if columnID == 'none':
			break
	
		print(datasetmatrix[0][int(columnID)])
	
		
	
		subset=[elem for elem in datasetmatrix[1:] if (float(elem[int(columnID)-1]) > float(morethen) and float(elem[int(columnID)-1]) < float(lessthen))]
		print("subset size is "+str(len(subset)))	
	
		print("color is "+color_input)
	
		color=color_input.split(',')
		

	
		if removeoverlay == 'yes':
				overlay=Overlay()
	
	
		
		
		
		x=[xshift+float(elem[X_coord_column-1])*scalingfactor for elem in subset]
		y=[yshift+float(elem[Y_coord_column-1])*scalingfactor for elem in subset]
		
		
		
		#	imp.show()
		
		
		for g in range(0,len(x)):
		
			col = Color(int(color[0]),int(color[1]),int(color[2]))
			roi = Roi(x[g]-5, y[g], 11, 1)
#			roi.setFillColor(col)
			roi.setStrokeColor(col)
#			roi.setStrokeWidth(1)
			overlay.add(roi)
			roi = Roi(x[g], y[g]-5, 1, 11)
#			roi.setFillColor(col)
			roi.setStrokeColor(col)
#			roi.setStrokeWidth(1)
			overlay.add(roi)
			
		imp.setOverlay(overlay)
		imp.show()
	
		wait=WaitForUserDialog('intensity driven cellfinder','press OK to continue')
		wait.show()
	

