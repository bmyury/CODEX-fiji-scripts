#this script locates and shows with crosses cells of a selected cluster
# niche_clustering.csv with is an export from Vortex and has cluster in the first column  is the input dataset file for this script

from ij import IJ, ImagePlus
from ij.io import DirectoryChooser, OpenDialog
from os import walk
import re
import os
from ij.gui import GenericDialog, Overlay, Roi, OvalRoi, PolygonRoi, TextRoi, WaitForUserDialog
from java.awt import Color, Checkbox
from ij.measure import ResultsTable
from ij.io import FileSaver
from ij.process import ImageStatistics, ImageProcessor, ByteProcessor



od = OpenDialog("Choose dataset file", None)  
datasetfile = od.getFileName() 
srcDir = od.getDirectory()
datasetpath = os.path.join(srcDir, od.getFileName())
datasetsource = open(datasetpath, "r+")


dc = DirectoryChooser("Choose directory for saving the results")
resultDir = dc.getDirectory()



gd = GenericDialog("how to split the table")
gd.addStringField("dataset OS Win or Mac (type none to exit the program)", "Win")
gd.addStringField("separator", "comma")
gd.showDialog()
eol=gd.getNextString()
separator=gd.getNextString()


if eol=="Win":
	datasetlines=datasetsource.read().split('\n')
if eol=="Mac":
	datasetlines=datasetsource.read().split('\r')
datasetsource.close()
print(len(datasetlines))


			
if separator=="comma":
	datasetmatrix=[datasetlines[i].split(",") for i in range(len(datasetlines)) if len(datasetlines[i].split(","))>3]
if separator=="tab":
	datasetmatrix=[datasetlines[i].split("\t") for i in range(len(datasetlines)) if len(datasetlines[i].split("\t"))>3]
print(len(datasetmatrix))

print("datasetmatrix size is "+str(len(datasetmatrix)))



gd = GenericDialog("scaling factor shift na imgtemplate params")
gd.addNumericField("width of img template", 4992,0)
gd.addNumericField("height of img template", 5760,0)
gd.addNumericField("scaling factor", 0.5,3)
gd.addNumericField("xshift", 0,3)
gd.addNumericField("yshift", 0,3)

gd.addNumericField("ObjectID column 1bases", 1,0)
gd.addNumericField("X coord column index 1 based", 4,3)
gd.addNumericField("Y coord column index 1 based", 5,3)

gd.showDialog()


width=int(gd.getNextNumber())
height=int(gd.getNextNumber())
scalingfactor=gd.getNextNumber()
xshift=gd.getNextNumber()
yshift=gd.getNextNumber()

object_ID_column=int(gd.getNextNumber())-1
X_coord_column=int(gd.getNextNumber())-1
Y_coord_column=int(gd.getNextNumber())-1

clustercol=[elem[object_ID_column] for elem in datasetmatrix[1:]]

uniqueids=list(set(clustercol))
print(len(clustercol))
print(len(uniqueids))
filledwithTrue=[True for elem in uniqueids]

gd = GenericDialog("cluster to draw in examplefiles")
gd.addCheckboxGroup(len(uniqueids)//3+4, 4, uniqueids, filledwithTrue)
gd.showDialog()
checkedIDs=gd.getCheckboxes()
IDs=[elem.getLabel() for elem in checkedIDs if elem.getState() is True]


for w in range(0,len(IDs)):

#	impnew=imp

	impnewprocessor=ByteProcessor(width,height)



	subset=[elem for elem in datasetmatrix[1:] if elem[object_ID_column]==IDs[w]]
		

	
		
	x=[xshift+float(elem[X_coord_column])*scalingfactor for elem in subset]
	y=[yshift+float(elem[Y_coord_column])*scalingfactor for elem in subset]
	

	for g in range(0,len(x)):


		impnewprocessor.setColor(255)
		impnewprocessor.fillOval(int(x[g]), int(y[g]), 10, 10)

	
#		col = Color(colors[g],0,0)
#		roi = OvalRoi(x[g], y[g], 20, 20)
#		roi.setStrokeColor(col)
#		roi.setStrokeWidth(1)
#		roi.setFillColor(col)
#		overlay.add(roi)

	filteredID=re.sub('[?\/()]', '-', IDs[w])
	
	impnew=ImagePlus(IDs[w],impnewprocessor)



	fs = FileSaver(impnew) 

	filepath = resultDir+"/size"+str(len(x))+"_ID"+filteredID+".tif"
	fs.saveAsTiff(filepath)




