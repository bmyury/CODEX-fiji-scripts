from ij import IJ, ImageStack, CompositeImage, ImagePlus
from ij.io import DirectoryChooser, OpenDialog
from os import walk
import re
import os
from ij.gui import GenericDialog,  WaitForUserDialog
from java.awt import Color


imp = IJ.getImage()
stack = imp.getImageStack()


gd = GenericDialog("How many markers do you wish to overlay")
gd.addNumericField("number of channels in result file", 3,0)
gd.addNumericField("number of channels in original file", 3,0)
gd.showDialog()
Nchannels_in_result=int(gd.getNextNumber())
Nchannels_in_ori=int(gd.getNextNumber())

frames=[]
channels=[]



forever="yes"

while  forever=="yes" :


	if len(frames)==0:
		gd = GenericDialog("frames and channels to combine")
		for i in range(1,Nchannels_in_result+1):
			gd.addNumericField("Frame-"+str(i), 2,1)
			gd.addNumericField("Channel of Frame-"+str(i), 2,1)
		gd.showDialog()
		combo = ImageStack(imp.width, imp.height)
		for i in range(0,Nchannels_in_result):	
			frames.append(int(gd.getNextNumber()))
			channels.append(int(gd.getNextNumber()))

	if len(frames)>1:
		gd = GenericDialog("frames and channels to combine")
		for i in range(1,Nchannels_in_result+1):
			gd.addNumericField("Frame-"+str(i), frames[i-1],1)
			gd.addNumericField("Channel of Frame-"+str(i), channels[i-1],1)
		gd.showDialog()
		combo = ImageStack(imp.width, imp.height)
		for i in range(0,Nchannels_in_result):	
			frames[i]=int(gd.getNextNumber())
			channels[i]=int(gd.getNextNumber())
	
	
	
	for k in range(1, Nchannels_in_result+1):  
		extract = stack.getProcessor((frames[k-1]-1)*Nchannels_in_ori+channels[k-1])
		combo.addSlice(extract) 
	
	#				combo.addSlice(cpwhite)
	
	imp2 = ImagePlus("selected  markers combined", combo)  
	imp2.setCalibration(imp.getCalibration().copy())	   
	imp2.setDimensions(Nchannels_in_result, 1, 1)
	
	
	comp = CompositeImage(imp2, CompositeImage.COMPOSITE)
	
	comp.show()

	wait=WaitForUserDialog('channel combinator','press OK to continue')
	wait.show()



	  
                                                                                                                                                                                                                                                                                                                                                


